var express = require("express");
var multer  = require('multer')
// Concatenar paths
var path = require("path"); 
// Modulo para realizas validaciones en formularios
const { check, validationResult } = require('express-validator');

app = express();

// Middleware que carga ficheros estaticos de un directorio (public en este caso).
// Es decir, podemos cargar los elementos que haya en public/
app.use(express.static(path.join(__dirname, "public")));

// View Engine 
app.set('view engine', 'ejs'); // motor de plantillas
app.set('views', path.join(__dirname, "views")); // carpeta donde guardar las vistas

// Middleware para el parseo de req.body
app.use(express.json()); // coge los datos en crudo y los pasa a json

// Que parsee datos que lleguen en la query HTTP y los deje como un objeto JSON 
app.use(express.urlencoded({extended: false})); 

// Declaracion y definicion de variables globales: en este caso errors
app.use(function (req, res, next) {
	res.locals.errors = null;
	next();
 });

app.get("/", function(req, res) { // peticion y respuesta como parametros
	res.render('index');
});

var storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, 'public/images/')
	},
	filename: function (req, file, cb) {
		cb(null, file.originalname)
	}
});


var uploadFilter = function (req, file, cb) {
	if (file.mimetype !== 'image/png' && file.mimetype !== 'image/jpeg') {
		return cb(new Error('Solo se permiten imágenes JPEG y PNG'));
	}
	cb(null, true);
}

var upload = multer({ 
	storage: storage,
	fileFilter: uploadFilter,
	limits: {
		fileSize: 2 * 1024 * 1024 // 2MB
	}
})
  
app.post('/upload/files', function (req, res) {
	upload.any('fileselect')(req, res, function (err) {
		var rutaArchivos = [];
		if (!err) {
			req.files.forEach(function(file) {
				rutaArchivos.push(file.path);
			});
			res.send({exito: true, newInfo: req.body, rutaArchivos});
		}
		else {
			console.log(err);
			res.send({exito: false, err});
		}
	});
});

app.listen(3000, function(){ // a la escucha en el puerto 3000
	console.log("Servidor lanzado en el puerto 3000");
});