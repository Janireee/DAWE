window.onload = function() {
	let links = document.getElementsByClassName("deleteUser");
	for (let item of links) {
	    item.addEventListener("click", deleteUser);
	}
	let linksEdit = document.getElementsByClassName("editUser");
	for (let item of linksEdit) {
	    item.addEventListener("click", editUser);
	}
}

function deleteUser(event){
    var confirmation = confirm('Are You Sure?');
	if(confirmation){
		var url = '/users/delete/' + event.target.getAttribute('data-id');
		var consulta = new XMLHttpRequest();
		consulta.open("DELETE", url);
		consulta.onload = function() {
			if (consulta.status == 200) {
				window.location.replace('/')
			}
		};
		consulta.send();
	} else {
		return false;
	}

}

function editUser(event){
	fetch('/users/insert/' + event.target.getAttribute('data-id'), {
		method: 'POST',
		headers: {
		  'Content-Type': 'application/json'
		}
	}).then((response) => response.json()).then((data) => {
		history.back();
		document.forms["form"].first_name.value = data.first_name;
		document.forms["form"].last_name.value = data.last_name;
		document.forms["form"].email.value = data.email;
		document.forms["form"].submit.value = "Editar";
		document.forms["form"].action = "/users/update/" + data._id;
		debugger;
	});
}	  

