var x = 0;
var y = 0;
var lienzo;
var context;
var base_image;
var cuadradoX = 30;
var cuadradoY = 40;

function inicializar() {
    lienzo = document.getElementById("lienzo");
    context = lienzo.getContext("2d");
    base_image = new Image();
    base_image.src = '../spritesheet.png';
    base_image.onload = function() {
        dibujar()                    
    }
    
    
    document.addEventListener("keydown", (event) => {
        const keyname = event.key;
        if(keyname === "ArrowUp"){
            if(y>0){
                y--;
                borrar();
                dibujar();
            }
            event.preventDefault();
        }
        else if(keyname === "ArrowDown"){
            if(y<base_image.height-cuadradoY){
                y++;
                borrar();
                dibujar();
            }
            event.preventDefault();
        }
        else if(keyname === "ArrowLeft"){
            if(x>0){
                x--;
                borrar();
                dibujar();
            }
            event.preventDefault();
        }
        else if(keyname === "ArrowRight"){
            if(x<base_image.width-cuadradoX){
                x++;
                borrar();
                dibujar();
            }
            event.preventDefault();
        }
    });

}

function borrar(){
    context.clearRect(0, 0, lienzo.width, lienzo.height);
}

function dibujar() {
    context.drawImage(base_image, 0, 0);
    context.strokeStyle = "red";
    context.strokeRect(x, y, cuadradoX, cuadradoY); 

    context.drawImage(base_image, x, y, cuadradoX, cuadradoY, base_image.width + 10, 0, cuadradoX * 2, cuadradoY * 2)

    context.fillText("(" + x + ", " + y + ")", base_image.width - 45, 10)
}

window.onload = inicializar