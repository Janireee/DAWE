class ArrayOrdenado {

    constructor (comparador)
    {
        this.comparador = comparador;
        this.contenido = [];
    }
    
    
    // Miramos que el el numero insertado sea menor que alguno de los que ya hay. En caso de no ser menor la funcion findIndex devolvera -1
    // Por lo que si es menor lo metemos en la posicion indicada, y en caso de ser el numero más alto en la última posición del array (ya que devolveria -1)
    findPos = (elt) => this.contenido.findIndex(x => x > elt) === -1 ?  this.contenido.length : this.contenido.findIndex(x => x > elt);
    
    insert = (elt) => this.contenido.splice(this.findPos(elt), 0, elt);
}
var ordenado = new ArrayOrdenado((a, b) => a - b );
ordenado.insert(5);
ordenado.insert(1);
ordenado.insert(2);
ordenado.insert(4);
ordenado.insert(3);
console.log("array:", ordenado.contenido);
// array: [1, 2, 3, 4, 5]


