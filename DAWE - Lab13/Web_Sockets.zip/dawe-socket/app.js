const express = require('express')
const app = express()
const fs = require('fs')
const https = require('https')
const http = require('http');

app.use(express.static(__dirname + '/public', { dotfiles: 'allow' } ))
app.get('/', (req, res) => {
	res.send('Hello HTTPS!')
})
/*http.createServer(app).listen(80, () => {
	console.log('Listening...')
})
https.createServer({ // otro servidor para HTTPS a la escucha en el puerto 443
	key: fs.readFileSync('/etc/letsencrypt/live/gartxon.me/privkey.pem'), // estas dos lineas hay que personalizarlas
	cert: fs.readFileSync('/etc/letsencrypt/live/gartxon.me/fullchain.pem')
}, app).listen(443, () => {
	console.log('Listening...')
})*/

module.exports = app;
