const serverURL = window.location.hostname + ":" +  window.location.port;
const socket = io.connect(serverURL, {secure: true});

export function setupSockets() {
        socket.emit("desktop-connect");

	socket.on("phone-move", function(data) {
		if (data < 0) {
			window.dispatchEvent(
				new KeyboardEvent('keydown', 
					{key: "ArrowLeft"
				})
			);
                        window.dispatchEvent(
                                new KeyboardEvent('keyup',
                                        {key: "ArrowLeft"
                                })
                        );
                }
		else if (data > 0) {
                        window.dispatchEvent(
                                new KeyboardEvent('keydown',
                                        {key: "ArrowRight"
                                })
                        );
                        window.dispatchEvent(
                                new KeyboardEvent('keyup',
                                        {key: "ArrowRight"
                                })
                        );
                }
	});
}

export function emitCrash() {
	socket.emit("crash");
}
