/* postits.js
 *
 */
var espacio = 0;
window.onload = init;

function init() {
	var button = document.getElementById("add_button");
	button.onclick = createSticky;

	var buttonBorrar = document.getElementById("delete_button");
	buttonBorrar.onclick = clearStickyNotes;

	var ocupacion = document.getElementById("ocupacion");

	// cargar las notas postit de localStorage  
	// cada nota se guarda como un par así: postit_X = texto_de_la_nota
	// donde X es el número de la nota
	// por cada una de ellas, llamar al método
	// addStickyToDOM(texto_de_la_nota);
	for (let i=1; i<=localStorage.length; i++) {
		debugger;
		if (localStorage.hasOwnProperty("postit_"+i)) {
			addStickyToDOM(localStorage.getItem("postit_"+i));
			espacio = espacio + (localStorage.getItem("postit_"+i).length * 16) / (8*1024);
		}
	}

	ocupacion.innerHTML = "Espacio utilizado: " + espacio + " KB";

}

function createSticky() {
	var value = document.getElementById("note_text").value;
	
        // crear la nota con nombre postit_X, donde X es un número entero
	// (postit_1, postit_2, ...)  y guardarla en el localStorage
	let stickerNumero = localStorage.length + 1;
	localStorage.setItem("postit_"+stickerNumero, value);

	espacio = espacio + (localStorage.getItem("postit_"+stickerNumero).length * 16) / (8*1024) ;

	ocupacion.innerHTML = "Espacio utilizado: " + espacio + " KB";

	addStickyToDOM(value);
}


function addStickyToDOM(value) {
	var stickies = document.getElementById("stickies");
	var postit = document.createElement("li");
	var span = document.createElement("span");
	span.setAttribute("class", "postit");
	span.innerHTML = value;
	postit.appendChild(span);
	stickies.appendChild(postit);
}

function clearStickyNotes() {
	// Crear un nuevo botón en la ventana de postit notes que al pulsarlo,
	// elimine las notas de pantalla y de localStorage
	// Algoritmo:	
	// obtener una referencia a la capa "stickies"
	// recorrer los hijos (childNodes) de esa referencia,
	// eliminándolos uno a uno (removeChild)
	let ref = document.getElementById("stickies");
	let numeroHijos = stickies.childNodes.length
	for(let i = numeroHijos-1; i > 0; i--) {
		ref.removeChild(ref.childNodes[i]);
		localStorage.removeItem("postit_"+i);
	}
	espacio = 0;
	ocupacion.innerHTML = "Espacio utilizado: " + espacio + " KB";

}
